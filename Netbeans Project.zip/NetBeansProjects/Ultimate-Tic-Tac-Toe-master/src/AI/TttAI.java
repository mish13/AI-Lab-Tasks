package AI;

public class TttAI {
	String AIPlayer ="O";
	TttAI(String player){
		super();
		AIPlayer = player;
	}
}
