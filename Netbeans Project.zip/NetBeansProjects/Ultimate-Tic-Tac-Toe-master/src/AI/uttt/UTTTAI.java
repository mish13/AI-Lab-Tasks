package AI.uttt;

import board.BoardBoard;

public interface UTTTAI {
	int getMove(BoardBoard board, String player);
}
